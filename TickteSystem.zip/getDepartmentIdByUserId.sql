SELECT
	department_id
FROM
	users
WHERE
	id = :id
