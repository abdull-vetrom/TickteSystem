SELECT
    department_id
FROM
    projects
WHERE
    id = :projectId
