SELECT
	password
FROM
	users
WHERE
	id = :id
