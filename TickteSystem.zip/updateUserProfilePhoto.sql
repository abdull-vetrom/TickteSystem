UPDATE
    users
SET
    photo_path = :path
WHERE
    id = :id
