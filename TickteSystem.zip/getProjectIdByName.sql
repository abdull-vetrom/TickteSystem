SELECT
	id
FROM
	projects
WHERE
	name = :name
