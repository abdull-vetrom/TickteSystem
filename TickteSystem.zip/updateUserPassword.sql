UPDATE
	users
SET
	password = :pwd
WHERE
	id = :id
