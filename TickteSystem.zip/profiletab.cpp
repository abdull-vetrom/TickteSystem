#include "profiletab.h"
#include "utils.h"
#include "storagemanager.h"

#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlError>
#include <QPixmap>
#include <QFileDialog>
#include <QFile>
#include <QDir>
#include <QDebug>
#include <QGroupBox>

ProfileTab::ProfileTab(int userId, QWidget *parent)
    : QWidget(parent), userId(userId) {
    labelName = new QLabel(this);
    labelEmail = new QLabel(this);
    labelRole = new QLabel(this);
    labelDept = new QLabel(this);

    labelName->setStyleSheet("font-weight: bold; font-size: 18px;");
    labelEmail->setStyleSheet("font-size: 16px;");
    labelRole->setStyleSheet("font-size: 16px;");
    labelDept->setStyleSheet("font-size: 16px;");

    photoLabel = new QLabel(this);
    photoLabel->setFixedSize(180, 240);
    photoLabel->setStyleSheet(
        "border: 2px solid #ccc;"
        "background: #f8f8f8;"
        "border-radius: 6px;");
    photoLabel->setAlignment(Qt::AlignCenter);

    uploadPhotoButton = new QPushButton("Загрузить фото", this);
    connect(uploadPhotoButton, &QPushButton::clicked, this, &ProfileTab::onUploadPhotoClicked);

    QVBoxLayout* photoLayout = new QVBoxLayout;
    photoLayout->addWidget(photoLabel, 0, Qt::AlignHCenter);
    photoLayout->addWidget(uploadPhotoButton, 0, Qt::AlignHCenter);
    photoLayout->addStretch();

    QVBoxLayout* infoLayout = new QVBoxLayout;
    infoLayout->addWidget(labelName);
    infoLayout->addWidget(labelEmail);
    infoLayout->addWidget(labelRole);
    infoLayout->addWidget(labelDept);
    infoLayout->addStretch();

    statsLayout = new QVBoxLayout;

    QHBoxLayout* mainLayout = new QHBoxLayout;
    mainLayout->addLayout(infoLayout, 3);
    mainLayout->addSpacing(20);
    mainLayout->addLayout(photoLayout, 1);
    mainLayout->addSpacing(40);
    mainLayout->addLayout(statsLayout, 2);

    setLayout(mainLayout);
    setStyleSheet(R"(
        QGroupBox {
            font-size: 16px;
            font-weight: bold;
            border: 1px solid #ccc;
            border-radius: 6px;
            margin-top: 10px;
        }
        QGroupBox::title {
            subcontrol-origin: margin;
            subcontrol-position: top center;
            padding: 0 6px;
        }
        QLabel {
            font-size: 14px;
            margin: 2px 0;
        }
    )");

    loadProfile();
}

void ProfileTab::loadProfile() {
    QSqlQuery query;
    QString sql = loadSqlQuery(":/sql/getUserProfileInfo.sql");
    query.prepare(sql);
    query.bindValue(":id", userId);

    if (query.exec() && query.next()) {
        QString firstName = query.value("first_name").toString();
        QString middleName = query.value("middle_name").toString();
        QString lastName  = query.value("last_name").toString();
        QString email     = query.value("email").toString();
        QString role      = query.value("role").toString();
        QString department = query.value("department").toString();
        QString photoPath = query.value("photo_path").toString();

        labelName->setText("👤 ФИО: " + lastName + " " + firstName + " " + middleName);
        labelEmail->setText("📧 Почта: " + email);
        labelRole->setText("🛡️ Роль: " + role);
        labelDept->setText("🏢 Отдел: " + department);

        if (!photoPath.isEmpty()) {
            QPixmap pix(StorageManager::getAbsolutePath(photoPath));
            photoLabel->setPixmap(pix.scaled(photoLabel->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation));
        }

        loadStatusStats();
        loadPriorityStats();
        if (role == "начальник") {
            loadProjectStats();
        }

    } else {
        qDebug() << "Ошибка загрузки профиля:" << query.lastError().text();
    }
}

void ProfileTab::loadStatusStats() {
    QSqlQuery q;
    q.prepare(loadSqlQuery(":/sql/getUserTicketCountByStatus.sql"));
    q.bindValue(":userId", userId);
    q.exec();

    QGroupBox* box = new QGroupBox("Статистика по статусам");
    QVBoxLayout* layout = new QVBoxLayout(box);

    while (q.next()) {
        layout->addWidget(new QLabel(QString("%1: %2")
                                         .arg(q.value("status").toString(), q.value("count").toString())));
    }

    statsLayout->addWidget(box);
}

void ProfileTab::loadPriorityStats() {
    QSqlQuery q;
    q.prepare(loadSqlQuery(":/sql/getUserTicketCountByPriority.sql"));
    q.bindValue(":userId", userId);
    q.exec();

    QGroupBox* box = new QGroupBox("Статистика по приоритетам");
    QVBoxLayout* layout = new QVBoxLayout(box);

    while (q.next()) {
        layout->addWidget(new QLabel(QString("%1: %2")
                                         .arg(q.value("priority").toString(), q.value("count").toString())));
    }

    statsLayout->addWidget(box);
}

void ProfileTab::loadProjectStats() {
    QSqlQuery q;
    q.prepare(loadSqlQuery(":/sql/getUserDepartmentProjectStats.sql"));
    q.bindValue(":userId", userId);
    q.exec();

    QSqlQuery departmnetNameSql;
    departmnetNameSql.prepare(loadSqlQuery(":/sql/getDepartmentNameByUser.sql"));
    departmnetNameSql.bindValue(":userId", userId);
    departmnetNameSql.exec();
    departmnetNameSql.next();

    QGroupBox* box = new QGroupBox("Статистика по проектам (" + departmnetNameSql.value("department_name").toString() + ")");
    QVBoxLayout* layout = new QVBoxLayout(box);

    while (q.next()) {
        layout->addWidget(new QLabel(QString("%1: %2")
                                         .arg(q.value("project").toString(), q.value("count").toString())));
    }

    statsLayout->addWidget(box);
}

void ProfileTab::onUploadPhotoClicked() {
    QString fileName = QFileDialog::getOpenFileName(this, "Выбрать фото", "", "Images (*.png *.jpg *.jpeg)");
    if (fileName.isEmpty()) return;

    QString relativePath = StorageManager::saveToStorage(fileName, "photos", QString("user_%1.png").arg(userId));
    if (relativePath.isEmpty()) {
        qDebug() << "Не удалось сохранить фото в storage";
        return;
    }

    QSqlQuery query;
    QString sql = loadSqlQuery(":/sql/updateUserProfilePhoto.sql");
    query.prepare(sql);
    query.bindValue(":path", relativePath);
    query.bindValue(":id", userId);
    if (!query.exec()) {
        qDebug() << "Ошибка сохранения фото:" << query.lastError().text();
        return;
    }

    QPixmap pix(StorageManager::getAbsolutePath(relativePath));
    photoLabel->setPixmap(pix.scaled(photoLabel->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation));
}

void ProfileTab::refreshStats() {
    // Очистка предыдущих виджетов статистики
    QLayoutItem* child;
    while ((child = statsLayout->takeAt(0)) != nullptr) {
        delete child->widget();
        delete child;
    }

    loadStatusStats();
    loadPriorityStats();
    loadProjectStats(); // безопасно вызывается даже если не начальник
}
