SELECT
    id,
    name
FROM
    priorities
