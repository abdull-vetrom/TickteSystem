SELECT
    name
FROM
    projects
