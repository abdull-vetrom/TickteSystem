SELECT
	name
FROM
	priorities

