SELECT
	name
FROM
	statuses

