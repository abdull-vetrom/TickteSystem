SELECT
    name
FROM
    trackers
